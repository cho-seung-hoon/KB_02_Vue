const p1 = { name: 'john', age: 20 };
p1.age = 22;
console.log(p1);
p1 = { name: 'lee', age: 25 };
//{ name: 'john', age: 22 }
// c:\Users\BlueSnack\Desktop\mykb\20250314\20250314_조승훈_기본\03_02-03.js:4
// p1 = { name: 'lee', age: 25 };
