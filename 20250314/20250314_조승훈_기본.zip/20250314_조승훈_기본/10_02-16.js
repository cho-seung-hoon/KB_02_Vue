let name = '홍길동';
let age = 20;
let email = 'gdhong@test.com';
let obj = { name, age, email };

console.log(obj);
