import { goodbye as bye, hi as hello } from './goodbye-3.mjs';

hello('eee');
bye('ghdrlfehd');
