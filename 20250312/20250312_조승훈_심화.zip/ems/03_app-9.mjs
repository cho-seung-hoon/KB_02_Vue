import * as say from './greeting-1.mjs';

say.hi('eee');
say.goodbye('ghdrlfehd');
