import { goodbye as bye } from './goodby-1.mjs';

bye('ghdrlfehd');
