const user = require('./07_user');
const hello = require('./08_hello');

console.log(user);
console.log(hello);
hello(user); // 모듈에서 가져온 user 변수와 hello 함수 사용하기
