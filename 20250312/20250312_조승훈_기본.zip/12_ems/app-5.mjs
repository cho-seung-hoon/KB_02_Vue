import { hi, goodbye } from './greeting-1.mjs';

goodbye('호일동');
