const fs = require('fs');

let files = fs.readdirSync('./');
console.log(files);
